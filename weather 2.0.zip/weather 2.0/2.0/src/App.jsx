import React from "react";
import WeatherApp from "./WeatherApp";
import "./App.css";                   

export default function App() {
  return (
    <div>
      <WeatherApp />
    </div>
  );
}