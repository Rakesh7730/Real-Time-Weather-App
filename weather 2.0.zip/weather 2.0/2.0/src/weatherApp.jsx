import React, { useState, useEffect } from "react";

export default function WeatherApp() {
  const [city, setCity] = useState("");
  const [weather, setWeather] = useState(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");

  const toCardinal = deg =>
    ["N", "NE", "E", "SE", "S", "SW", "W", "NW"][Math.round(deg / 45) % 8];

  const getWeather = async () => {
    if (!city.trim()) return setError("Please enter a valid city name.");
    setLoading(true); setError(""); setWeather(null);
    try {
      const geo = await (await fetch(`https://geocoding-api.open-meteo.com/v1/search?name=${encodeURIComponent(city)}&count=1`)).json();
      if (!geo.results?.length) return setError("City not found.");
      const { latitude, longitude, name, admin1, country } = geo.results[0];
      const place = [name, admin1, country].filter(Boolean).join(", ");
      const wx = await (await fetch(`https://api.open-meteo.com/v1/forecast?latitude=${latitude}&longitude=${longitude}&current_weather=true&timezone=auto`)).json();
      const { temperature, windspeed, winddirection, time } = wx.current_weather;
      setWeather({ temp: Math.round(temperature), place, tz: wx.timezone, time, wind: windspeed, windDir: `${winddirection}° (${toCardinal(winddirection)})` });
    } catch { setError("Something went wrong. Try again."); }
    finally { setLoading(false); }
  };

  useEffect(() => {
    const stars = Array.from({ length: 100 }, () => {
      const s = document.createElement("div");
      Object.assign(s.style, {
        position: "fixed", width: `${Math.random() * 2 + 1}px`, height: `${Math.random() * 2 + 1}px`,
        background: "white", borderRadius: "50%", top: `${Math.random()*100}vh`, left: `${Math.random()*100}vw`,
        opacity: Math.random(), pointerEvents: "none", transition: "opacity 1s, transform 0.5s"
      });
      document.body.appendChild(s); return s;
    });
    const twinkle = setInterval(() => stars.forEach(s => s.style.opacity = Math.random()), 500);
    const mouseMove = e => stars.forEach((s,i) => s.style.transform = `translate(${(e.clientX/window.innerWidth-0.5)*i*0.5}px, ${(e.clientY/window.innerHeight-0.5)*i*0.5}px)`);
    window.addEventListener("mousemove", mouseMove);
    return () => { clearInterval(twinkle); window.removeEventListener("mousemove", mouseMove); stars.forEach(s => document.body.removeChild(s)); };
  }, []);

  return (
    <div className="weather-container">
      <h1 className="title">City Weather</h1>
      <div className="input-group">
        <input value={city} onChange={e=>setCity(e.target.value)} onKeyDown={e=>e.key==="Enter"&&getWeather()} placeholder="Enter a city" />
        <button onClick={getWeather} disabled={loading}>{loading?"Loading…":"Get Weather"}</button>
      </div>
      {error && <div className="error">{error}</div>}
      {weather && <div className="weather-box">
        <h2>{weather.place}</h2>
        <p>{weather.temp}°C</p>
        <p>Wind: {weather.wind} m/s ({weather.windDir})</p>
        <p>As of {new Date(weather.time).toLocaleString()} ({weather.tz})</p>
      </div>}
    </div>
  );
}
